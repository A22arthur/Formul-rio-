<?php
require 'conexao.php';

// Consulta para obter todos os vídeos cadastrados
$sql = "SELECT * FROM videos";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Função para transformar o link do YouTube em formato embed
function getEmbedUrl($link) {
    if (strpos($link, 'youtube.com') !== false) {
        parse_str(parse_url($link, PHP_URL_QUERY), $params);
        return 'https://www.youtube.com/embed/' . $params['v'];
    }
    return null; // Retorna null caso não seja do YouTube
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Listar Vídeos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .card {
            margin: 20px;
            width: 18rem;
        }
        .card img {
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Lista de Vídeos</h1>
        <div class="row">
            <?php foreach ($videos as $video): ?>
                <div class="col-md-4">
                    <div class="card">
                        <img class="card-img-top" src="https://img.youtube.com/vi/<?php echo substr(parse_url($video['link'], PHP_URL_PATH), 1); ?>/hqdefault.jpg" alt="Thumbnail do vídeo">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($video['nome']); ?></h5>
                            <a href="<?php echo htmlspecialchars($video['link']); ?>" class="btn btn-primary" target="_blank">Assistir</a>
                            <iframe src="<?php echo htmlspecialchars(getEmbedUrl($video['link'])); ?>" allowfullscreen style="display:none;"></iframe>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
